package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.englishLetters.EnglishLettersRepository
import com.example.data.banglaSorborno.BanglaSorbornoRepository
import com.example.data.banglaBanjonborno.BanglaBanjonbornoRepository
import com.example.data.numbersEnglish.NumbersEnglishRepository
import com.example.data.numbersBangla.NumbersBanglaRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app_name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Kiddo Learn", appName)
  }

  @Test
  fun `verify english letters json loaded`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = EnglishLettersRepository(context)
    val letters = repo.getEnglishLetters()
    assertEquals(26, letters.size)
    assertEquals("A", letters.first().character)
    assertEquals("Z", letters.last().character)
  }

  @Test
  fun `verify bangla vowels loaded`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = BanglaSorbornoRepository(context)
    val vowels = repo.getBanglaSorborno()
    assertEquals(11, vowels.size)
    assertEquals("অ", vowels.first().character)
    assertEquals("ঔ", vowels.last().character)
  }

  @Test
  fun `verify numbers loaded`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val enRepo = NumbersEnglishRepository(context)
    val bnRepo = NumbersBanglaRepository(context)
    assertEquals(20, enRepo.getNumbersEnglish().size)
    assertEquals(20, bnRepo.getNumbersBangla().size)
  }
}
