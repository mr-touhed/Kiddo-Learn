package com.example

import com.example.ui.game.snakeCore.Direction
import com.example.ui.game.snakeCore.EatResult
import com.example.ui.game.snakeCore.Position
import com.example.ui.game.snakeCore.SequenceProvider
import com.example.ui.game.snakeCore.SnakeEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SnakeEngineSequenceTest {

    private class MockSequenceProvider(override val sequence: List<String>) : SequenceProvider

    @Test
    fun testInitialStateStartsWithFirstTarget() {
        val provider = MockSequenceProvider(listOf("A", "B", "C"))
        val engine = SnakeEngine(sequenceProvider = provider, gridWidth = 10, gridHeight = 10)

        assertEquals("A", engine.state.targetCharacter)
        assertEquals(0, engine.state.targetIndex)
        assertEquals(3, engine.state.lives)
        assertFalse(engine.state.isGameOver)
        assertFalse(engine.state.isVictory)
    }

    @Test
    fun testDirectionCannotDirectlyReverse() {
        val provider = MockSequenceProvider(listOf("A", "B"))
        val engine = SnakeEngine(sequenceProvider = provider)

        // Initially moving UP
        assertEquals(Direction.UP, engine.state.direction)

        // Trying to reverse directly to DOWN should be ignored
        engine.changeDirection(Direction.DOWN)
        assertEquals(Direction.UP, engine.state.direction)

        // Turning RIGHT is valid
        engine.changeDirection(Direction.RIGHT)
        assertEquals(Direction.RIGHT, engine.state.direction)

        // Then turning LEFT should be ignored (since opposite of RIGHT)
        engine.changeDirection(Direction.LEFT)
        assertEquals(Direction.RIGHT, engine.state.direction)
    }

    @Test
    fun testEatingCorrectTargetAdvancesSequence() {
        val provider = MockSequenceProvider(listOf("A", "B", "C"))
        val engine = SnakeEngine(sequenceProvider = provider, gridWidth = 10, gridHeight = 10)

        // Position target right in front of snake head
        val head = engine.state.snake.first()
        // Snake moves UP, so position target at head.x, head.y - 1
        val targetPos = Position(head.x, head.y - 1)

        // Override food items directly in state for controlled test
        // By simulating stepping onto target
        val field = engine.javaClass.getDeclaredField("state")
        field.isAccessible = true
        val curState = engine.state
        val customFoods = listOf(
            com.example.ui.game.snakeCore.FoodItem(targetPos, "A", isTarget = true)
        )
        field.set(engine, curState.copy(foodItems = customFoods))

        val result = engine.step()

        assertTrue(result is EatResult.Correct)
        val correct = result as EatResult.Correct
        assertEquals("A", correct.character)
        assertEquals("B", correct.nextTarget)
        assertFalse(correct.isSequenceComplete)
        assertEquals("B", engine.state.targetCharacter)
        assertEquals(1, engine.state.targetIndex)
        assertEquals(10, engine.state.score)
    }

    @Test
    fun testEatingWrongFoodLosesHeart() {
        val provider = MockSequenceProvider(listOf("A", "B", "C"))
        val engine = SnakeEngine(sequenceProvider = provider, gridWidth = 10, gridHeight = 10)

        val head = engine.state.snake.first()
        val wrongPos = Position(head.x, head.y - 1)

        val field = engine.javaClass.getDeclaredField("state")
        field.isAccessible = true
        val curState = engine.state
        val customFoods = listOf(
            com.example.ui.game.snakeCore.FoodItem(wrongPos, "Z", isTarget = false)
        )
        field.set(engine, curState.copy(foodItems = customFoods))

        val result = engine.step()

        assertTrue(result is EatResult.Wrong)
        val wrong = result as EatResult.Wrong
        assertEquals("Z", wrong.character)
        assertEquals(2, wrong.livesRemaining)
        assertEquals(2, engine.state.lives)
        assertFalse(wrong.isGameOver)
    }

    @Test
    fun testCompletingSequenceTriggersVictory() {
        val provider = MockSequenceProvider(listOf("A"))
        val engine = SnakeEngine(sequenceProvider = provider, gridWidth = 10, gridHeight = 10)

        val head = engine.state.snake.first()
        val targetPos = Position(head.x, head.y - 1)

        val field = engine.javaClass.getDeclaredField("state")
        field.isAccessible = true
        val curState = engine.state
        val customFoods = listOf(
            com.example.ui.game.snakeCore.FoodItem(targetPos, "A", isTarget = true)
        )
        field.set(engine, curState.copy(foodItems = customFoods))

        val result = engine.step()

        assertTrue(result is EatResult.Correct)
        val correct = result as EatResult.Correct
        assertTrue(correct.isSequenceComplete)
        assertTrue(engine.state.isVictory)
    }
}
