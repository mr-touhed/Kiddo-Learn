package com.example.domain.model

enum class Language(val displayName: String, val code: String) {
    EN("English", "en"),
    BN("বাংলা", "bn")
}

data class LearningItem(
    val character: String,
    val exampleWord: String,
    val pronunciation: String,
    val meaning: String,
    val emoji: String,
    val phonetic: String,
    val colorHex: String,
    val language: Language
)

data class GameHighScore(
    val gameId: String,
    val highScore: Int,
    val highestSequence: String,
    val completedCount: Int,
    val updatedAt: Long
)
