package com.example.ui.game.gameMenu

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.common.ui.KidGiantButton
import com.example.common.ui.KidTopBar

@Composable
fun GameMenuScreen(
    onNavigateBack: () -> Unit,
    onNavigateToSnakeEnglish: () -> Unit,
    onNavigateToSnakeSorborno: () -> Unit,
    onNavigateToSnakeBanjonborno: () -> Unit,
    onNavigateToSnakeNumbers: () -> Unit,
    viewModel: GameMenuViewModel = viewModel()
) {
    val scores by viewModel.scores.collectAsState()
    var isSoundOn by remember { mutableStateOf(viewModel.audioHelper.isSoundOn()) }

    LaunchedEffect(Unit) {
        viewModel.loadScores()
    }

    BackHandler {
        onNavigateBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFFFF9C4), Color(0xFFFFECB3), Color(0xFFFFCC80))
                )
            )
            .testTag("game_menu_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            KidTopBar(
                title = "🎮 Snake Games (সাপের খেলা)",
                subtitle = "Choose your favorite learning game!",
                onBackClick = onNavigateBack,
                isSoundOn = isSoundOn,
                onToggleSound = {
                    isSoundOn = viewModel.audioHelper.toggleSound()
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. English Snake
                KidGiantButton(
                    title = "🔤 English Snake",
                    subtitle = "A → B → C … Z • Best: ${scores.englishHighScore}",
                    emoji = "🐍",
                    gradientColors = listOf(Color(0xFF00B0FF), Color(0xFF0091EA)),
                    onClick = {
                        viewModel.audioHelper.playClickSound()
                        onNavigateToSnakeEnglish()
                    },
                    testTag = "game_menu_btn_english"
                )

                // 2. Sorborno Snake
                KidGiantButton(
                    title = "🅰 স্বরবর্ণ সাপ",
                    subtitle = "অ → আ → ই … ঔ • সেরা স্কোর: ${scores.sorbornoHighScore}",
                    emoji = "🥭",
                    gradientColors = listOf(Color(0xFF43A047), Color(0xFF2E7D32)),
                    onClick = {
                        viewModel.audioHelper.playClickSound()
                        onNavigateToSnakeSorborno()
                    },
                    testTag = "game_menu_btn_sorborno"
                )

                // 3. Banjonborno Snake
                KidGiantButton(
                    title = "🅲 ব্যঞ্জনবর্ণ সাপ",
                    subtitle = "ক → খ → গ … হ • সেরা স্কোর: ${scores.banjonbornoHighScore}",
                    emoji = "🐯",
                    gradientColors = listOf(Color(0xFFFF9800), Color(0xFFE65100)),
                    onClick = {
                        viewModel.audioHelper.playClickSound()
                        onNavigateToSnakeBanjonborno()
                    },
                    testTag = "game_menu_btn_banjonborno"
                )

                // 4. Number Snake
                KidGiantButton(
                    title = "🔢 Number Snake",
                    subtitle = "1 → 2 → 3 … 20 (EN & বাংলা) • Best: ${scores.numbersHighScore}",
                    emoji = "🎈",
                    gradientColors = listOf(Color(0xFFAB47BC), Color(0xFF7B1FA2)),
                    onClick = {
                        viewModel.audioHelper.playClickSound()
                        onNavigateToSnakeNumbers()
                    },
                    testTag = "game_menu_btn_numbers"
                )
            }
        }
    }
}
