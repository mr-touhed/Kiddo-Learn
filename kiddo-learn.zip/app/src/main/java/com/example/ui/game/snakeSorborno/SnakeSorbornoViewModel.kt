package com.example.ui.game.snakeSorborno

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.common.audio.AudioHelper
import com.example.data.banglaSorborno.BanglaSorbornoRepository
import com.example.data.database.AppDatabase
import com.example.data.database.HighScoreEntity
import com.example.domain.model.Language
import com.example.ui.game.snakeCore.Direction
import com.example.ui.game.snakeCore.EatResult
import com.example.ui.game.snakeCore.SequenceProvider
import com.example.ui.game.snakeCore.SnakeEngine
import com.example.ui.game.snakeCore.SnakeGameState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SnakeSorbornoViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = BanglaSorbornoRepository(application)
    private val dao = AppDatabase.getInstance(application).highScoreDao()
    val audioHelper = AudioHelper(application)

    private val vowels = repository.getBanglaSorborno()
    val vowelChars = vowels.map { it.character }

    private val sequenceProvider = object : SequenceProvider {
        override val sequence: List<String> = vowelChars
    }

    private val engine = SnakeEngine(sequenceProvider = sequenceProvider, gridWidth = 11, gridHeight = 12)

    private val _gameState = MutableStateFlow(engine.state)
    val gameState: StateFlow<SnakeGameState> = _gameState.asStateFlow()

    private val _highScore = MutableStateFlow(0)
    val highScore: StateFlow<Int> = _highScore.asStateFlow()

    private var gameLoopJob: Job? = null

    init {
        loadHighScore()
        startGameLoop()
    }

    private fun loadHighScore() {
        viewModelScope.launch {
            val record = dao.getHighScore("snake_sorborno")
            _highScore.value = record?.highScore ?: 0
        }
    }

    fun startGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            while (true) {
                delay(350)
                val result = engine.step()
                _gameState.value = engine.state

                when (result) {
                    is EatResult.Correct -> {
                        audioHelper.playBiteSound()
                        val item = vowels.find { it.character == result.character }
                        audioHelper.speak(result.character, Language.BN, item?.phonetic ?: "")
                        checkAndSaveHighScore(engine.state.score, result.character)
                        if (result.isSequenceComplete) {
                            audioHelper.playVictorySound()
                        }
                    }
                    is EatResult.Wrong -> {
                        audioHelper.playWrongSound()
                    }
                    EatResult.None -> {}
                }
            }
        }
    }

    fun changeDirection(dir: Direction) {
        engine.changeDirection(dir)
        _gameState.value = engine.state
    }

    fun togglePause() {
        val nextPaused = !engine.state.isPaused
        engine.setPaused(nextPaused)
        _gameState.value = engine.state
    }

    fun restartGame() {
        engine.reset()
        _gameState.value = engine.state
    }

    private fun checkAndSaveHighScore(score: Int, lastChar: String) {
        if (score > _highScore.value) {
            _highScore.value = score
        }
        viewModelScope.launch {
            dao.insertOrUpdate(
                HighScoreEntity(
                    gameId = "snake_sorborno",
                    highScore = maxOf(_highScore.value, score),
                    highestSequence = lastChar,
                    completedCount = if (engine.state.isVictory) 1 else 0,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        gameLoopJob?.cancel()
        audioHelper.shutdown()
    }
}
