package com.example.ui.game.snakeCore

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.Paint
import android.graphics.Typeface

data class SnakeThemeColors(
    val boardBackground: Color,
    val boardGridLines: Color,
    val snakeHead: Color,
    val snakeBody: Color,
    val snakeEye: Color = Color.Black,
    val targetFoodBg: Color,
    val targetFoodText: Color,
    val otherFoodBg: Color,
    val otherFoodText: Color
)

@Composable
fun SnakeBoardView(
    state: SnakeGameState,
    themeColors: SnakeThemeColors,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(state.gridWidth.toFloat() / state.gridHeight.toFloat())
            .clip(RoundedCornerShape(24.dp))
            .shadow(6.dp, RoundedCornerShape(24.dp))
            .background(themeColors.boardBackground)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cellW = size.width / state.gridWidth
            val cellH = size.height / state.gridHeight

            // Draw subtle cell pattern
            for (gx in 0 until state.gridWidth) {
                for (gy in 0 until state.gridHeight) {
                    if ((gx + gy) % 2 == 1) {
                        drawRect(
                            color = themeColors.boardGridLines,
                            topLeft = Offset(gx * cellW, gy * cellH),
                            size = Size(cellW, cellH)
                        )
                    }
                }
            }

            // Draw food items
            val textPaintTarget = Paint().apply {
                color = android.graphics.Color.argb(
                    (themeColors.targetFoodText.alpha * 255).toInt(),
                    (themeColors.targetFoodText.red * 255).toInt(),
                    (themeColors.targetFoodText.green * 255).toInt(),
                    (themeColors.targetFoodText.blue * 255).toInt()
                )
                textSize = cellH * 0.58f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            val textPaintOther = Paint().apply {
                color = android.graphics.Color.argb(
                    (themeColors.otherFoodText.alpha * 255).toInt(),
                    (themeColors.otherFoodText.red * 255).toInt(),
                    (themeColors.otherFoodText.green * 255).toInt(),
                    (themeColors.otherFoodText.blue * 255).toInt()
                )
                textSize = cellH * 0.54f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isAntiAlias = true
            }

            state.foodItems.forEach { food ->
                val centerX = food.position.x * cellW + cellW / 2f
                val centerY = food.position.y * cellH + cellH / 2f
                val radius = minOf(cellW, cellH) * 0.44f

                // Outer glow / circle
                val bgColor = if (food.isTarget) themeColors.targetFoodBg else themeColors.otherFoodBg
                drawCircle(
                    color = bgColor,
                    radius = radius,
                    center = Offset(centerX, centerY)
                )

                if (food.isTarget) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.5f),
                        radius = radius * 0.35f,
                        center = Offset(centerX - radius * 0.3f, centerY - radius * 0.3f)
                    )
                }

                val paint = if (food.isTarget) textPaintTarget else textPaintOther
                val fontMetrics = paint.fontMetrics
                val textBaseline = centerY - (fontMetrics.ascent + fontMetrics.descent) / 2f

                drawContext.canvas.nativeCanvas.drawText(
                    food.character,
                    centerX,
                    textBaseline,
                    paint
                )
            }

            // Draw snake body
            state.snake.forEachIndexed { index, pos ->
                val left = pos.x * cellW + cellW * 0.08f
                val top = pos.y * cellH + cellH * 0.08f
                val width = cellW * 0.84f
                val height = cellH * 0.84f

                val isHead = index == 0
                val color = if (isHead) themeColors.snakeHead else themeColors.snakeBody

                drawRoundRect(
                    color = color,
                    topLeft = Offset(left, top),
                    size = Size(width, height),
                    cornerRadius = CornerRadius(if (isHead) cellW * 0.42f else cellW * 0.28f)
                )

                // If head, draw cute eyes
                if (isHead) {
                    val eyeRadius = cellW * 0.10f
                    val eyeWhiteRadius = cellW * 0.15f
                    val headCenterX = left + width / 2f
                    val headCenterY = top + height / 2f

                    val (eye1Offset, eye2Offset) = when (state.direction) {
                        Direction.UP -> Pair(
                            Offset(headCenterX - cellW * 0.22f, headCenterY - cellH * 0.15f),
                            Offset(headCenterX + cellW * 0.22f, headCenterY - cellH * 0.15f)
                        )
                        Direction.DOWN -> Pair(
                            Offset(headCenterX - cellW * 0.22f, headCenterY + cellH * 0.15f),
                            Offset(headCenterX + cellW * 0.22f, headCenterY + cellH * 0.15f)
                        )
                        Direction.LEFT -> Pair(
                            Offset(headCenterX - cellW * 0.15f, headCenterY - cellH * 0.22f),
                            Offset(headCenterX - cellW * 0.15f, headCenterY + cellH * 0.22f)
                        )
                        Direction.RIGHT -> Pair(
                            Offset(headCenterX + cellW * 0.15f, headCenterY - cellH * 0.22f),
                            Offset(headCenterX + cellW * 0.15f, headCenterY + cellH * 0.22f)
                        )
                    }

                    // Eye whites
                    drawCircle(color = Color.White, radius = eyeWhiteRadius, center = eye1Offset)
                    drawCircle(color = Color.White, radius = eyeWhiteRadius, center = eye2Offset)
                    // Eye pupils
                    drawCircle(color = themeColors.snakeEye, radius = eyeRadius, center = eye1Offset)
                    drawCircle(color = themeColors.snakeEye, radius = eyeRadius, center = eye2Offset)
                }
            }
        }
    }
}
