package com.example.ui.game.snakeNumbers

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.common.audio.AudioHelper
import com.example.data.database.AppDatabase
import com.example.data.database.HighScoreEntity
import com.example.data.numbersBangla.NumbersBanglaRepository
import com.example.data.numbersEnglish.NumbersEnglishRepository
import com.example.domain.model.Language
import com.example.ui.game.snakeCore.Direction
import com.example.ui.game.snakeCore.EatResult
import com.example.ui.game.snakeCore.SequenceProvider
import com.example.ui.game.snakeCore.SnakeEngine
import com.example.ui.game.snakeCore.SnakeGameState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SnakeNumbersViewModel(application: Application) : AndroidViewModel(application) {
    private val enRepo = NumbersEnglishRepository(application)
    private val bnRepo = NumbersBanglaRepository(application)
    private val dao = AppDatabase.getInstance(application).highScoreDao()
    val audioHelper = AudioHelper(application)

    private val _currentLanguage = MutableStateFlow(Language.EN)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    private val enItems = enRepo.getNumbersEnglish()
    private val bnItems = bnRepo.getNumbersBangla()

    private var activeEngine: SnakeEngine = createEngineForLanguage(Language.EN)

    private val _gameState = MutableStateFlow(activeEngine.state)
    val gameState: StateFlow<SnakeGameState> = _gameState.asStateFlow()

    private val _highScore = MutableStateFlow(0)
    val highScore: StateFlow<Int> = _highScore.asStateFlow()

    private var gameLoopJob: Job? = null

    init {
        loadHighScore()
        startGameLoop()
    }

    private fun createEngineForLanguage(lang: Language): SnakeEngine {
        val list = if (lang == Language.EN) enItems.map { it.character } else bnItems.map { it.character }
        val provider = object : SequenceProvider {
            override val sequence: List<String> = list
        }
        return SnakeEngine(sequenceProvider = provider, gridWidth = 11, gridHeight = 12)
    }

    private fun loadHighScore() {
        val gameId = if (_currentLanguage.value == Language.EN) "snake_numbers_en" else "snake_numbers_bn"
        viewModelScope.launch {
            val record = dao.getHighScore(gameId)
            _highScore.value = record?.highScore ?: 0
        }
    }

    fun setLanguage(lang: Language) {
        if (_currentLanguage.value != lang) {
            _currentLanguage.value = lang
            activeEngine = createEngineForLanguage(lang)
            _gameState.value = activeEngine.state
            loadHighScore()
        }
    }

    fun startGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            while (true) {
                delay(350)
                val result = activeEngine.step()
                _gameState.value = activeEngine.state

                when (result) {
                    is EatResult.Correct -> {
                        audioHelper.playBiteSound()
                        val currentList = if (_currentLanguage.value == Language.EN) enItems else bnItems
                        val item = currentList.find { it.character == result.character }
                        audioHelper.speak(result.character, _currentLanguage.value, item?.phonetic ?: "")
                        checkAndSaveHighScore(activeEngine.state.score, result.character)
                        if (result.isSequenceComplete) {
                            audioHelper.playVictorySound()
                        }
                    }
                    is EatResult.Wrong -> {
                        audioHelper.playWrongSound()
                    }
                    EatResult.None -> {}
                }
            }
        }
    }

    fun changeDirection(dir: Direction) {
        activeEngine.changeDirection(dir)
        _gameState.value = activeEngine.state
    }

    fun togglePause() {
        val nextPaused = !activeEngine.state.isPaused
        activeEngine.setPaused(nextPaused)
        _gameState.value = activeEngine.state
    }

    fun restartGame() {
        activeEngine.reset()
        _gameState.value = activeEngine.state
    }

    private fun checkAndSaveHighScore(score: Int, lastChar: String) {
        if (score > _highScore.value) {
            _highScore.value = score
        }
        val gameId = if (_currentLanguage.value == Language.EN) "snake_numbers_en" else "snake_numbers_bn"
        viewModelScope.launch {
            dao.insertOrUpdate(
                HighScoreEntity(
                    gameId = gameId,
                    highScore = maxOf(_highScore.value, score),
                    highestSequence = lastChar,
                    completedCount = if (activeEngine.state.isVictory) 1 else 0,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        gameLoopJob?.cancel()
        audioHelper.shutdown()
    }
}
