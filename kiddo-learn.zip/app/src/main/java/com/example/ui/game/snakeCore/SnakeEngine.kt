package com.example.ui.game.snakeCore

import kotlin.random.Random

enum class Direction {
    UP, DOWN, LEFT, RIGHT;

    fun isOpposite(other: Direction): Boolean {
        return (this == UP && other == DOWN) ||
                (this == DOWN && other == UP) ||
                (this == LEFT && other == RIGHT) ||
                (this == RIGHT && other == LEFT)
    }
}

data class Position(val x: Int, val y: Int)

data class FoodItem(
    val position: Position,
    val character: String,
    val isTarget: Boolean
)

sealed class EatResult {
    object None : EatResult()
    data class Correct(val character: String, val nextTarget: String?, val isSequenceComplete: Boolean) : EatResult()
    data class Wrong(val character: String, val livesRemaining: Int, val isGameOver: Boolean) : EatResult()
}

interface SequenceProvider {
    val sequence: List<String>
    val totalCount: Int get() = sequence.size
    fun getItemAt(index: Int): String? = sequence.getOrNull(index)
}

data class SnakeGameState(
    val snake: List<Position> = listOf(Position(5, 7), Position(5, 8), Position(5, 9)),
    val direction: Direction = Direction.UP,
    val targetIndex: Int = 0,
    val targetCharacter: String = "",
    val foodItems: List<FoodItem> = emptyList(),
    val lives: Int = 3,
    val score: Int = 0,
    val isVictory: Boolean = false,
    val isGameOver: Boolean = false,
    val isPaused: Boolean = false,
    val lastEatenCharacter: String? = null,
    val gridWidth: Int = 11,
    val gridHeight: Int = 13
)

class SnakeEngine(
    private val sequenceProvider: SequenceProvider,
    val gridWidth: Int = 11,
    val gridHeight: Int = 13
) {
    var state = SnakeGameState(
        gridWidth = gridWidth,
        gridHeight = gridHeight,
        targetCharacter = sequenceProvider.sequence.firstOrNull() ?: ""
    )
        private set

    init {
        reset()
    }

    fun reset() {
        val initialSnake = listOf(
            Position(gridWidth / 2, gridHeight / 2),
            Position(gridWidth / 2, gridHeight / 2 + 1),
            Position(gridWidth / 2, gridHeight / 2 + 2)
        )
        val firstTarget = sequenceProvider.sequence.firstOrNull() ?: ""
        state = SnakeGameState(
            snake = initialSnake,
            direction = Direction.UP,
            targetIndex = 0,
            targetCharacter = firstTarget,
            lives = 3,
            score = 0,
            isVictory = false,
            isGameOver = false,
            isPaused = false,
            gridWidth = gridWidth,
            gridHeight = gridHeight
        )
        spawnFood()
    }

    fun setPaused(paused: Boolean) {
        state = state.copy(isPaused = paused)
    }

    fun changeDirection(newDir: Direction) {
        if (state.isPaused || state.isGameOver || state.isVictory) return
        if (newDir != state.direction && !newDir.isOpposite(state.direction)) {
            state = state.copy(direction = newDir)
        }
    }

    fun step(): EatResult {
        if (state.isPaused || state.isGameOver || state.isVictory) return EatResult.None

        val head = state.snake.first()
        var newHeadX = head.x
        var newHeadY = head.y

        when (state.direction) {
            Direction.UP -> newHeadY -= 1
            Direction.DOWN -> newHeadY += 1
            Direction.LEFT -> newHeadX -= 1
            Direction.RIGHT -> newHeadX += 1
        }

        // Kid-friendly boundary wrap-around so little kids don't abruptly crash into walls
        if (newHeadX < 0) newHeadX = gridWidth - 1
        if (newHeadX >= gridWidth) newHeadX = 0
        if (newHeadY < 0) newHeadY = gridHeight - 1
        if (newHeadY >= gridHeight) newHeadY = 0

        val newHead = Position(newHeadX, newHeadY)

        // Check food collision
        val eatenFood = state.foodItems.find { it.position == newHead }

        var grow = false
        var eatResult: EatResult = EatResult.None

        if (eatenFood != null) {
            if (eatenFood.isTarget) {
                // Correct item eaten!
                grow = true
                val newTargetIndex = state.targetIndex + 1
                val isComplete = newTargetIndex >= sequenceProvider.sequence.size
                val nextTarget = if (!isComplete) sequenceProvider.sequence[newTargetIndex] else null

                eatResult = EatResult.Correct(
                    character = eatenFood.character,
                    nextTarget = nextTarget,
                    isSequenceComplete = isComplete
                )

                state = state.copy(
                    targetIndex = newTargetIndex,
                    targetCharacter = nextTarget ?: "",
                    score = state.score + 10,
                    isVictory = isComplete,
                    lastEatenCharacter = eatenFood.character
                )

                if (!isComplete) {
                    spawnFood()
                }
            } else {
                // Wrong item eaten - soft penalty (lose 1 heart)
                val remainingLives = state.lives - 1
                val isOver = remainingLives <= 0

                eatResult = EatResult.Wrong(
                    character = eatenFood.character,
                    livesRemaining = remainingLives,
                    isGameOver = isOver
                )

                state = state.copy(
                    lives = remainingLives,
                    isGameOver = isOver
                )
                // Respawn food items so board stays fresh
                spawnFood()
            }
        }

        // Update snake body
        val newBody = mutableListOf<Position>()
        newBody.add(newHead)
        val bodyLimit = if (grow) state.snake.size else state.snake.size - 1
        for (i in 0 until bodyLimit) {
            newBody.add(state.snake[i])
        }

        state = state.copy(snake = newBody)
        return eatResult
    }

    private fun spawnFood() {
        val occupied = state.snake.toMutableSet()
        val emptyPositions = mutableListOf<Position>()

        for (x in 0 until gridWidth) {
            for (y in 0 until gridHeight) {
                val p = Position(x, y)
                if (!occupied.contains(p)) {
                    emptyPositions.add(p)
                }
            }
        }

        emptyPositions.shuffle()

        val items = mutableListOf<FoodItem>()
        val targetChar = state.targetCharacter

        if (targetChar.isNotEmpty() && emptyPositions.isNotEmpty()) {
            val targetPos = emptyPositions.removeAt(0)
            items.add(FoodItem(position = targetPos, character = targetChar, isTarget = true))
            occupied.add(targetPos)

            // Pick 2 distractor characters from the sequence that are NOT the target
            val candidates = sequenceProvider.sequence.filter { it != targetChar }.shuffled()
            val distractorsCount = minOf(2, candidates.size, emptyPositions.size)

            for (i in 0 until distractorsCount) {
                val distractorChar = candidates[i]
                val pos = emptyPositions.removeAt(0)
                items.add(FoodItem(position = pos, character = distractorChar, isTarget = false))
                occupied.add(pos)
            }
        }

        state = state.copy(foodItems = items)
    }
}
