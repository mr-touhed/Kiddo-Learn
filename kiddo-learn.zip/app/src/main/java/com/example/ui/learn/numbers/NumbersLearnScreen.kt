package com.example.ui.learn.numbers

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.common.ui.KidTopBar
import com.example.domain.model.Language

@Composable
fun NumbersLearnScreen(
    onNavigateBack: () -> Unit,
    viewModel: NumbersLearnViewModel = viewModel()
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val currentIndex by viewModel.currentIndex.collectAsState()
    val isGridView by viewModel.isGridView.collectAsState()
    val items = viewModel.getItems()
    var isSoundOn by remember { mutableStateOf(viewModel.audioHelper.isSoundOn()) }

    BackHandler {
        onNavigateBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFFCE4EC), Color(0xFFF8BBD0), Color(0xFFE1BEE7))
                )
            )
            .testTag("numbers_learn_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            KidTopBar(
                title = if (currentLang == Language.EN) "🔢 Numbers (1 to 20)" else "🔢 সংখ্যা (১ থেকে ২০)",
                subtitle = if (currentLang == Language.EN) "Count objects with fun sounds!" else "ছবি দেখে সংখ্যা গণনা করো!",
                onBackClick = onNavigateBack,
                isSoundOn = isSoundOn,
                onToggleSound = {
                    isSoundOn = viewModel.audioHelper.toggleSound()
                }
            )

            // Language Toggle Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                FilterChip(
                    selected = currentLang == Language.EN,
                    onClick = { viewModel.setLanguage(Language.EN) },
                    label = { Text("English 1-20", fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFD81B60),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("learn_numbers_en_chip")
                )
                Spacer(modifier = Modifier.width(12.dp))
                FilterChip(
                    selected = currentLang == Language.BN,
                    onClick = { viewModel.setLanguage(Language.BN) },
                    label = { Text("বাংলা ১-২০", fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFD81B60),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("learn_numbers_bn_chip")
                )
            }

            // View toggle & counter
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Text(
                        text = "${currentIndex + 1} / ${items.size}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF880E4F),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 3.dp,
                    modifier = Modifier.size(46.dp)
                ) {
                    IconButton(
                        onClick = { viewModel.toggleViewMode() },
                        modifier = Modifier.testTag("numbers_toggle_grid")
                    ) {
                        Icon(
                            imageVector = if (isGridView) Icons.Default.Style else Icons.Default.GridView,
                            contentDescription = "Toggle Grid",
                            tint = Color(0xFFD81B60)
                        )
                    }
                }
            }

            if (isGridView) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("numbers_letters_grid")
                ) {
                    itemsIndexed(items) { index, item ->
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (index == currentIndex) Color(0xFFFFD54F) else Color.White
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { viewModel.selectIndex(index) }
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = item.character,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFD81B60)
                                )
                                Text(
                                    text = item.exampleWord,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            } else {
                val currentItem = items.getOrNull(currentIndex)
                if (currentItem != null) {
                    AnimatedContent(
                        targetState = currentItem,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "numbers_card_anim",
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 24.dp, vertical = 8.dp)
                    ) { item ->
                        Card(
                            shape = RoundedCornerShape(36.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(36.dp))
                                .clickable { viewModel.speakCurrentItem() }
                                .testTag("numbers_flashcard")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.SpaceEvenly
                            ) {
                                // Giant Number
                                Box(
                                    modifier = Modifier
                                        .size(110.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFCE4EC)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = item.character,
                                        fontSize = 72.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFFC2185B)
                                    )
                                }

                                // Emoji counting objects
                                Text(
                                    text = item.emoji,
                                    fontSize = if (item.emoji.length > 4) 40.sp else 70.sp,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )

                                // Word & Count
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = item.exampleWord,
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF263238)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = item.meaning,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFFD81B60)
                                    )
                                }

                                // Speaker Tap Button
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0xFFFF4081),
                                    shadowElevation = 4.dp,
                                    modifier = Modifier.size(64.dp)
                                ) {
                                    IconButton(
                                        onClick = { viewModel.speakCurrentItem() },
                                        modifier = Modifier.testTag("numbers_card_speak_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.VolumeUp,
                                            contentDescription = "Pronounce Number",
                                            tint = Color.White,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Bottom Navigation Buttons (Next / Prev)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.previousItem() },
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .testTag("numbers_prev_btn"),
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Previous",
                                tint = Color(0xFFD81B60),
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (currentLang == Language.EN) "Previous" else "আগেরটি",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD81B60)
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Button(
                            onClick = { viewModel.nextItem() },
                            modifier = Modifier
                                .weight(1f)
                                .height(64.dp)
                                .testTag("numbers_next_btn"),
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD81B60)),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                        ) {
                            Text(
                                text = if (currentLang == Language.EN) "Next" else "পরেরটি",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Next",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
