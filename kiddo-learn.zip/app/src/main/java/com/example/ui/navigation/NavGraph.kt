package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.game.gameMenu.GameMenuScreen
import com.example.ui.game.snakeBanjonborno.SnakeBanjonbornoScreen
import com.example.ui.game.snakeEnglish.SnakeEnglishScreen
import com.example.ui.game.snakeNumbers.SnakeNumbersScreen
import com.example.ui.game.snakeSorborno.SnakeSorbornoScreen
import com.example.ui.home.HomeScreen
import com.example.ui.learn.banglaBanjonborno.BanglaBanjonbornoLearnScreen
import com.example.ui.learn.banglaSorborno.BanglaSorbornoLearnScreen
import com.example.ui.learn.english.EnglishLearnScreen
import com.example.ui.learn.learnMenu.LearnMenuScreen
import com.example.ui.learn.numbers.NumbersLearnScreen

object NavRoutes {
    const val HOME = "home"
    const val LEARN_MENU = "learn_menu"
    const val LEARN_ENGLISH = "learn_english"
    const val LEARN_BANGLA_SORBORNO = "learn_bangla_sorborno"
    const val LEARN_BANGLA_BANJONBORNO = "learn_bangla_banjonborno"
    const val LEARN_NUMBERS = "learn_numbers"
    const val GAME_MENU = "game_menu"
    const val GAME_SNAKE_ENGLISH = "game_snake_english"
    const val GAME_SNAKE_SORBORNO = "game_snake_sorborno"
    const val GAME_SNAKE_BANJONBORNO = "game_snake_banjonborno"
    const val GAME_SNAKE_NUMBERS = "game_snake_numbers"
}

@Composable
fun KiddoNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        startDestination = NavRoutes.HOME
    ) {
        // Home
        composable(NavRoutes.HOME) {
            HomeScreen(
                onNavigateToLearn = { navController.navigate(NavRoutes.LEARN_MENU) },
                onNavigateToGame = { navController.navigate(NavRoutes.GAME_MENU) }
            )
        }

        // Learn Menu
        composable(NavRoutes.LEARN_MENU) {
            LearnMenuScreen(
                onNavigateBack = { navController.popBackStack() },
                onNavigateToEnglish = { navController.navigate(NavRoutes.LEARN_ENGLISH) },
                onNavigateToSorborno = { navController.navigate(NavRoutes.LEARN_BANGLA_SORBORNO) },
                onNavigateToBanjonborno = { navController.navigate(NavRoutes.LEARN_BANGLA_BANJONBORNO) },
                onNavigateToNumbers = { navController.navigate(NavRoutes.LEARN_NUMBERS) }
            )
        }

        // 4 Separated Learn Screens
        composable(NavRoutes.LEARN_ENGLISH) {
            EnglishLearnScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(NavRoutes.LEARN_BANGLA_SORBORNO) {
            BanglaSorbornoLearnScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(NavRoutes.LEARN_BANGLA_BANJONBORNO) {
            BanglaBanjonbornoLearnScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(NavRoutes.LEARN_NUMBERS) {
            NumbersLearnScreen(onNavigateBack = { navController.popBackStack() })
        }

        // Game Menu
        composable(NavRoutes.GAME_MENU) {
            GameMenuScreen(
                onNavigateBack = { navController.popBackStack() },
                onNavigateToSnakeEnglish = { navController.navigate(NavRoutes.GAME_SNAKE_ENGLISH) },
                onNavigateToSnakeSorborno = { navController.navigate(NavRoutes.GAME_SNAKE_SORBORNO) },
                onNavigateToSnakeBanjonborno = { navController.navigate(NavRoutes.GAME_SNAKE_BANJONBORNO) },
                onNavigateToSnakeNumbers = { navController.navigate(NavRoutes.GAME_SNAKE_NUMBERS) }
            )
        }

        // 4 Separated Snake Game Screens
        composable(NavRoutes.GAME_SNAKE_ENGLISH) {
            SnakeEnglishScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(NavRoutes.GAME_SNAKE_SORBORNO) {
            SnakeSorbornoScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(NavRoutes.GAME_SNAKE_BANJONBORNO) {
            SnakeBanjonbornoScreen(onNavigateBack = { navController.popBackStack() })
        }

        composable(NavRoutes.GAME_SNAKE_NUMBERS) {
            SnakeNumbersScreen(onNavigateBack = { navController.popBackStack() })
        }
    }
}
