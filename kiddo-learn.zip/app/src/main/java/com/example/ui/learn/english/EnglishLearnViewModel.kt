package com.example.ui.learn.english

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.common.audio.AudioHelper
import com.example.data.englishLetters.EnglishLettersRepository
import com.example.domain.model.Language
import com.example.domain.model.LearningItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class EnglishLearnViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = EnglishLettersRepository(application)
    val audioHelper = AudioHelper(application)

    val items: List<LearningItem> = repository.getEnglishLetters()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isGridView = MutableStateFlow(false)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    init {
        // Speak first item initially when ready
        speakCurrentItem()
    }

    fun nextItem() {
        if (items.isNotEmpty()) {
            _currentIndex.value = (_currentIndex.value + 1) % items.size
            speakCurrentItem()
        }
    }

    fun previousItem() {
        if (items.isNotEmpty()) {
            _currentIndex.value = if (_currentIndex.value > 0) _currentIndex.value - 1 else items.size - 1
            speakCurrentItem()
        }
    }

    fun selectIndex(index: Int) {
        if (index in items.indices) {
            _currentIndex.value = index
            _isGridView.value = false
            speakCurrentItem()
        }
    }

    fun toggleViewMode() {
        _isGridView.value = !_isGridView.value
    }

    fun speakCurrentItem() {
        if (_currentIndex.value in items.indices) {
            val item = items[_currentIndex.value]
            audioHelper.speak("${item.character}. ${item.pronunciation}", Language.EN)
        }
    }

    fun speakItem(item: LearningItem) {
        audioHelper.speak("${item.character}. ${item.pronunciation}", Language.EN)
    }

    override fun onCleared() {
        super.onCleared()
        audioHelper.shutdown()
    }
}
