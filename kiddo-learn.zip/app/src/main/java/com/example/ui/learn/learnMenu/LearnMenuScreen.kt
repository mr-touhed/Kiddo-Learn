package com.example.ui.learn.learnMenu

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.common.audio.AudioHelper
import com.example.common.ui.KidGiantButton
import com.example.common.ui.KidTopBar

@Composable
fun LearnMenuScreen(
    onNavigateBack: () -> Unit,
    onNavigateToEnglish: () -> Unit,
    onNavigateToSorborno: () -> Unit,
    onNavigateToBanjonborno: () -> Unit,
    onNavigateToNumbers: () -> Unit
) {
    val context = LocalContext.current
    val audioHelper = remember { AudioHelper(context) }
    var isSoundOn by remember { mutableStateOf(audioHelper.isSoundOn()) }

    BackHandler {
        onNavigateBack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFE8F5E9), Color(0xFFE0F7FA), Color(0xFFFFF9C4))
                )
            )
            .testTag("learn_menu_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            KidTopBar(
                title = "📚 Learn (শিখো)",
                subtitle = "Choose what you want to learn today!",
                onBackClick = onNavigateBack,
                isSoundOn = isSoundOn,
                onToggleSound = {
                    isSoundOn = audioHelper.toggleSound()
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. English A-Z
                KidGiantButton(
                    title = "🔤 English ABC",
                    subtitle = "Learn A to Z with 26 colorful words!",
                    emoji = "🍎",
                    gradientColors = listOf(Color(0xFF29B6F6), Color(0xFF0288D1)),
                    onClick = {
                        audioHelper.playClickSound()
                        onNavigateToEnglish()
                    },
                    testTag = "learn_menu_btn_english"
                )

                // 2. Bangla Sorborno
                KidGiantButton(
                    title = "🅰 বাংলা স্বরবর্ণ",
                    subtitle = "অ, আ, ই, ঈ … ১১টি স্বরবর্ণ শেখো",
                    emoji = "🥭",
                    gradientColors = listOf(Color(0xFF66BB6A), Color(0xFF2E7D32)),
                    onClick = {
                        audioHelper.playClickSound()
                        onNavigateToSorborno()
                    },
                    testTag = "learn_menu_btn_sorborno"
                )

                // 3. Bangla Banjonborno
                KidGiantButton(
                    title = "🅲 বাংলা ব্যঞ্জনবর্ণ",
                    subtitle = "ক, খ, গ, ঘ … ৩৯টি ব্যঞ্জনবর্ণ শেখো",
                    emoji = "🐯",
                    gradientColors = listOf(Color(0xFFFFA726), Color(0xFFE65100)),
                    onClick = {
                        audioHelper.playClickSound()
                        onNavigateToBanjonborno()
                    },
                    testTag = "learn_menu_btn_banjonborno"
                )

                // 4. Numbers
                KidGiantButton(
                    title = "🔢 Numbers & সংখ্যা",
                    subtitle = "1 to 20 & ১ থেকে ২০ গণনা ও ছবি",
                    emoji = "🎈",
                    gradientColors = listOf(Color(0xFFEC407A), Color(0xFFC2185B)),
                    onClick = {
                        audioHelper.playClickSound()
                        onNavigateToNumbers()
                    },
                    testTag = "learn_menu_btn_numbers"
                )
            }
        }
    }
}
