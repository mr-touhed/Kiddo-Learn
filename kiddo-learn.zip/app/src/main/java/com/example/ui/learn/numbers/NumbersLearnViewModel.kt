package com.example.ui.learn.numbers

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.common.audio.AudioHelper
import com.example.data.numbersBangla.NumbersBanglaRepository
import com.example.data.numbersEnglish.NumbersEnglishRepository
import com.example.domain.model.Language
import com.example.domain.model.LearningItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NumbersLearnViewModel(application: Application) : AndroidViewModel(application) {
    private val enRepo = NumbersEnglishRepository(application)
    private val bnRepo = NumbersBanglaRepository(application)
    val audioHelper = AudioHelper(application)

    private val enItems = enRepo.getNumbersEnglish()
    private val bnItems = bnRepo.getNumbersBangla()

    private val _currentLanguage = MutableStateFlow(Language.EN)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isGridView = MutableStateFlow(false)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    fun getItems(): List<LearningItem> {
        return if (_currentLanguage.value == Language.EN) enItems else bnItems
    }

    init {
        speakCurrentItem()
    }

    fun setLanguage(lang: Language) {
        if (_currentLanguage.value != lang) {
            _currentLanguage.value = lang
            speakCurrentItem()
        }
    }

    fun nextItem() {
        val list = getItems()
        if (list.isNotEmpty()) {
            _currentIndex.value = (_currentIndex.value + 1) % list.size
            speakCurrentItem()
        }
    }

    fun previousItem() {
        val list = getItems()
        if (list.isNotEmpty()) {
            _currentIndex.value = if (_currentIndex.value > 0) _currentIndex.value - 1 else list.size - 1
            speakCurrentItem()
        }
    }

    fun selectIndex(index: Int) {
        val list = getItems()
        if (index in list.indices) {
            _currentIndex.value = index
            _isGridView.value = false
            speakCurrentItem()
        }
    }

    fun toggleViewMode() {
        _isGridView.value = !_isGridView.value
    }

    fun speakCurrentItem() {
        val list = getItems()
        if (_currentIndex.value in list.indices) {
            val item = list[_currentIndex.value]
            audioHelper.speak("${item.character}. ${item.exampleWord}", _currentLanguage.value, item.phonetic)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioHelper.shutdown()
    }
}
