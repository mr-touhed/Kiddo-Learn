package com.example.ui.game.gameMenu

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.common.audio.AudioHelper
import com.example.data.database.AppDatabase
import com.example.data.database.HighScoreEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class GameScores(
    val englishHighScore: Int = 0,
    val sorbornoHighScore: Int = 0,
    val banjonbornoHighScore: Int = 0,
    val numbersHighScore: Int = 0
)

class GameMenuViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getInstance(application).highScoreDao()
    val audioHelper = AudioHelper(application)

    private val _scores = MutableStateFlow(GameScores())
    val scores: StateFlow<GameScores> = _scores.asStateFlow()

    init {
        loadScores()
    }

    fun loadScores() {
        viewModelScope.launch {
            val en = dao.getHighScore("snake_english")?.highScore ?: 0
            val sorborno = dao.getHighScore("snake_sorborno")?.highScore ?: 0
            val banjonborno = dao.getHighScore("snake_banjonborno")?.highScore ?: 0
            val numEn = dao.getHighScore("snake_numbers_en")?.highScore ?: 0
            val numBn = dao.getHighScore("snake_numbers_bn")?.highScore ?: 0
            _scores.value = GameScores(
                englishHighScore = en,
                sorbornoHighScore = sorborno,
                banjonbornoHighScore = banjonborno,
                numbersHighScore = maxOf(numEn, numBn)
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioHelper.shutdown()
    }
}
