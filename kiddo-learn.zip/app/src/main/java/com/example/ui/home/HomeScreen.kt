package com.example.ui.home

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.common.audio.AudioHelper
import com.example.common.ui.KidGiantButton
import com.example.common.ui.ParentalGateDialog

@Composable
fun HomeScreen(
    onNavigateToLearn: () -> Unit,
    onNavigateToGame: () -> Unit
) {
    val context = LocalContext.current
    val audioHelper = remember { AudioHelper(context) }
    var isSoundOn by remember { mutableStateOf(audioHelper.isSoundOn()) }
    var showParentalGate by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }

    // Subtle gentle float animation for mascot
    val infiniteTransition = rememberInfiniteTransition(label = "mascot_bounce")
    val mascotScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFFFF9C4), // Gentle sunshine yellow
                        Color(0xFFFFE0B2), // Soft apricot
                        Color(0xFFFFCCBC)  // Warm peach
                    )
                )
            )
            .testTag("home_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar: Sound toggle & Parent info button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.9f),
                    shadowElevation = 4.dp,
                    modifier = Modifier.size(50.dp)
                ) {
                    IconButton(
                        onClick = {
                            isSoundOn = audioHelper.toggleSound()
                        },
                        modifier = Modifier.testTag("home_sound_toggle")
                    ) {
                        Icon(
                            imageVector = if (isSoundOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Sound Toggle",
                            tint = if (isSoundOn) Color(0xFF43A047) else Color(0xFFE53935),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.9f),
                    shadowElevation = 4.dp,
                    modifier = Modifier.size(50.dp)
                ) {
                    IconButton(
                        onClick = { showParentalGate = true },
                        modifier = Modifier.testTag("home_parent_gate_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Parent Gate",
                            tint = Color(0xFFF57C00),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // App Mascot & Title
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .scale(mascotScale)
                        .size(130.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_launcher_icon_1793159875939),
                        contentDescription = "Cute mascot snake and letter blocks",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Kiddo Learn",
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF37474F),
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "হাতেখড়ি ও সাপের খেলা 🌟",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE65100)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "English & Bangla Alphabet + Numbers",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF546E7A)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Two Giant Buttons (The 2 Primary Actions required by prompt)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Button 1: Learn (শিখো)
                KidGiantButton(
                    title = "📚 Learn (শিখো)",
                    subtitle = "ABC • স্বরবর্ণ • ব্যঞ্জনবর্ণ • সংখ্যা",
                    emoji = "🎒",
                    gradientColors = listOf(Color(0xFF00C853), Color(0xFF2E7D32)),
                    onClick = {
                        audioHelper.playClickSound()
                        onNavigateToLearn()
                    },
                    modifier = Modifier.height(120.dp),
                    testTag = "home_btn_learn"
                )

                // Button 2: Game (খেলা)
                KidGiantButton(
                    title = "🎮 Game (খেলা)",
                    subtitle = "4 Separated Fun Snake Games!",
                    emoji = "🐍",
                    gradientColors = listOf(Color(0xFFFF9100), Color(0xFFFF3D00)),
                    onClick = {
                        audioHelper.playClickSound()
                        onNavigateToGame()
                    },
                    modifier = Modifier.height(120.dp),
                    testTag = "home_btn_game"
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Encouragement Badge
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🎈", fontSize = 18.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "100% Offline • Safe for Kids • No Ads",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF455A64)
                    )
                }
            }
        }

        // Parental Gate Dialog
        ParentalGateDialog(
            isOpen = showParentalGate,
            onDismiss = { showParentalGate = false },
            onSuccess = {
                showParentalGate = false
                showInfoDialog = true
            }
        )

        // Parent Information & COPPA compliance dialog
        if (showInfoDialog) {
            Dialog(onDismissRequest = { showInfoDialog = false }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Grown-Up Info 👨‍👩‍👧",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF263238)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Kiddo Learn is designed for young children ages 3–7 to master English & Bangla alphabets and numbers through joyful interactive cards and educational snake games.\n\n" +
                                    "• 100% Offline: No internet connection is ever needed.\n" +
                                    "• Privacy First: Zero data collection, no analytics, no ads, no trackers.\n" +
                                    "• Gentle Learning: No time pressures or harsh punishments.",
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            color = Color(0xFF546E7A)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF0091EA),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                        ) {
                            IconButton(onClick = { showInfoDialog = false }) {
                                Text(
                                    text = "Close",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
