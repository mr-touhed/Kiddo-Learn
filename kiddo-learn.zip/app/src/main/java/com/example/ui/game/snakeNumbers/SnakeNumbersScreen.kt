package com.example.ui.game.snakeNumbers

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.common.ui.ArrowDPad
import com.example.common.ui.ConfettiCelebration
import com.example.common.ui.HeartLivesBar
import com.example.common.ui.KidTopBar
import com.example.common.ui.ParentalGateDialog
import com.example.common.ui.SwipeController
import com.example.domain.model.Language
import com.example.ui.game.snakeCore.SnakeBoardView
import com.example.ui.game.snakeCore.SnakeThemeColors

@Composable
fun SnakeNumbersScreen(
    onNavigateBack: () -> Unit,
    viewModel: SnakeNumbersViewModel = viewModel()
) {
    val state by viewModel.gameState.collectAsState()
    val highScore by viewModel.highScore.collectAsState()
    val currentLang by viewModel.currentLanguage.collectAsState()
    var isSoundOn by remember { mutableStateOf(viewModel.audioHelper.isSoundOn()) }
    var showParentalGate by remember { mutableStateOf(false) }

    BackHandler {
        showParentalGate = true
    }

    val numbersTheme = remember {
        SnakeThemeColors(
            boardBackground = Color(0xFFF3E5F5),
            boardGridLines = Color(0xFFE1BEE7),
            snakeHead = Color(0xFF7B1FA2),
            snakeBody = Color(0xFFBA68C8),
            targetFoodBg = Color(0xFFFF4081),
            targetFoodText = Color.White,
            otherFoodBg = Color(0xFFCFD8DC),
            otherFoodText = Color(0xFF455A64)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFFCE4EC), Color(0xFFEDE7F6))
                )
            )
            .testTag("snake_numbers_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 12.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            KidTopBar(
                title = "🔢 Number Snake",
                subtitle = if (currentLang == Language.EN) "Eat numbers 1 to 20!" else "১ থেকে ২০ পর্যন্ত খাও!",
                onBackClick = { showParentalGate = true },
                isSoundOn = isSoundOn,
                onToggleSound = {
                    isSoundOn = viewModel.audioHelper.toggleSound()
                }
            )

            // Language Toggle Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                FilterChip(
                    selected = currentLang == Language.EN,
                    onClick = { viewModel.setLanguage(Language.EN) },
                    label = { Text("1 2 3 English", fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFAB47BC),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("number_snake_en_chip")
                )
                Spacer(modifier = Modifier.width(12.dp))
                FilterChip(
                    selected = currentLang == Language.BN,
                    onClick = { viewModel.setLanguage(Language.BN) },
                    label = { Text("১ ২ ৩ বাংলা", fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFAB47BC),
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("number_snake_bn_chip")
                )
            }

            // Status HUD
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                HeartLivesBar(currentLives = state.lives)

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFF4081)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.testTag("target_number_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (currentLang == Language.EN) "Find: " else "খোঁজো: ",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = state.targetCharacter,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFFFF9C4)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                viewModel.audioHelper.speak(state.targetCharacter, currentLang)
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Hear target",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.9f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (currentLang == Language.EN) "Score" else "স্কোর",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Gray
                        )
                        Text(
                            text = "${state.score}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF7B1FA2)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // The Snake Board
            SwipeController(
                onDirectionChange = { dir -> viewModel.changeDirection(dir) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                SnakeBoardView(
                    state = state,
                    themeColors = numbersTheme,
                    modifier = Modifier.testTag("numbers_snake_board")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = Color.White,
                        shadowElevation = 3.dp,
                        modifier = Modifier.size(48.dp)
                    ) {
                        IconButton(onClick = { viewModel.togglePause() }) {
                            Icon(
                                imageVector = if (state.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                contentDescription = "Pause",
                                tint = Color(0xFF7B1FA2)
                            )
                        }
                    }
                    Surface(
                        shape = CircleShape,
                        color = Color.White,
                        shadowElevation = 3.dp,
                        modifier = Modifier.size(48.dp)
                    ) {
                        IconButton(onClick = { viewModel.restartGame() }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Restart",
                                tint = Color(0xFFAB47BC)
                            )
                        }
                    }
                }

                ArrowDPad(
                    onDirectionChange = { dir -> viewModel.changeDirection(dir) },
                    modifier = Modifier.testTag("numbers_dpad")
                )
            }
        }

        ConfettiCelebration(isActive = state.isVictory)

        if (state.isVictory) {
            Dialog(onDismissRequest = {}) {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🎉🎈🔢", fontSize = 42.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (currentLang == Language.EN) "You Counted All!" else "সব সংখ্যা শেষ করেছো!",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF7B1FA2)
                        )
                        Text(
                            text = if (currentLang == Language.EN)
                                "Awesome! You conquered 1 to 20!"
                            else "চমৎকার! তুমি ১ থেকে ২০ পর্যন্ত সবগুলো গুনে ফেলেছ!",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Score: ${state.score}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFF4081)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { viewModel.restartGame() },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFAB47BC))
                        ) {
                            Text(text = "Play Again! 🔄", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onNavigateBack,
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA000))
                        ) {
                            Text(text = "Menu 🏠", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (state.isGameOver) {
            Dialog(onDismissRequest = {}) {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🌟🚀", fontSize = 38.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (currentLang == Language.EN) "Nice Try!" else "দারুণ চেষ্টা!",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF37474F)
                        )
                        Text(
                            text = if (currentLang == Language.EN)
                                "You reached number ${state.targetCharacter}! Want to play again?"
                            else "তুমি ${state.targetCharacter} পর্যন্ত গিয়েছিলে। আবার খেলবে?",
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            color = Color.Gray
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.restartGame() },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFAB47BC))
                        ) {
                            Text(text = "Try Again 🔄", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onNavigateBack,
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF90A4AE))
                        ) {
                            Text(text = "Game Menu 🏠", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        ParentalGateDialog(
            isOpen = showParentalGate,
            onDismiss = { showParentalGate = false },
            onSuccess = {
                showParentalGate = false
                onNavigateBack()
            }
        )
    }
}
