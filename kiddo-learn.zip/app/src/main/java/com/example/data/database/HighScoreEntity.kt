package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "high_scores")
data class HighScoreEntity(
    @PrimaryKey
    val gameId: String,
    val highScore: Int,
    val highestSequence: String,
    val completedCount: Int,
    val updatedAt: Long
)
