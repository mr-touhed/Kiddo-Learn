package com.example.data.englishLetters

import android.content.Context
import com.example.domain.model.Language
import com.example.domain.model.LearningItem
import org.json.JSONArray
import java.io.InputStreamReader

class EnglishLettersRepository(private val context: Context) {
    private var cachedItems: List<LearningItem>? = null

    fun getEnglishLetters(): List<LearningItem> {
        cachedItems?.let { return it }

        val items = mutableListOf<LearningItem>()
        try {
            val jsonString = context.assets.open("data/english_letters.json").use { inputStream ->
                InputStreamReader(inputStream).readText()
            }
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                items.add(
                    LearningItem(
                        character = obj.getString("character"),
                        exampleWord = obj.getString("exampleWord"),
                        pronunciation = obj.getString("pronunciation"),
                        meaning = obj.optString("meaning", ""),
                        emoji = obj.getString("emoji"),
                        phonetic = obj.optString("phonetic", ""),
                        colorHex = obj.optString("colorHex", "#FF5252"),
                        language = Language.EN
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        cachedItems = items
        return items
    }
}
