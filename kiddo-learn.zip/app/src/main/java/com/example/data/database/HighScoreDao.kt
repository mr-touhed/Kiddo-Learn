package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HighScoreDao {
    @Query("SELECT * FROM high_scores WHERE gameId = :gameId")
    fun getHighScoreFlow(gameId: String): Flow<HighScoreEntity?>

    @Query("SELECT * FROM high_scores WHERE gameId = :gameId")
    suspend fun getHighScore(gameId: String): HighScoreEntity?

    @Query("SELECT * FROM high_scores")
    fun getAllHighScoresFlow(): Flow<List<HighScoreEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(score: HighScoreEntity)
}
