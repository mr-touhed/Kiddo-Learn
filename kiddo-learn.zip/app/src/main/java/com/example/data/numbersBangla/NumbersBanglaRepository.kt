package com.example.data.numbersBangla

import android.content.Context
import com.example.domain.model.Language
import com.example.domain.model.LearningItem
import org.json.JSONArray
import java.io.InputStreamReader

class NumbersBanglaRepository(private val context: Context) {
    private var cachedItems: List<LearningItem>? = null

    fun getNumbersBangla(): List<LearningItem> {
        cachedItems?.let { return it }

        val items = mutableListOf<LearningItem>()
        try {
            val jsonString = context.assets.open("data/numbers_bangla.json").use { inputStream ->
                InputStreamReader(inputStream).readText()
            }
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                items.add(
                    LearningItem(
                        character = obj.getString("character"),
                        exampleWord = obj.getString("exampleWord"),
                        pronunciation = obj.getString("pronunciation"),
                        meaning = obj.optString("meaning", ""),
                        emoji = obj.getString("emoji"),
                        phonetic = obj.optString("phonetic", ""),
                        colorHex = obj.optString("colorHex", "#E53935"),
                        language = Language.BN
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        cachedItems = items
        return items
    }
}
