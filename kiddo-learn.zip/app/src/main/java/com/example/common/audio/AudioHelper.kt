package com.example.common.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.widget.Toast
import com.example.domain.model.Language
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sin

class AudioHelper(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var isBanglaSupported = false
    private var isSoundEnabled = true

    private val banglaLocale = Locale("bn", "BD")

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            tts?.language = Locale.US
            tts?.setSpeechRate(0.85f)
            tts?.setPitch(1.15f) // Slightly higher, friendly pitch for kids

            val bnAvailable = tts?.isLanguageAvailable(banglaLocale)
            isBanglaSupported = bnAvailable == TextToSpeech.LANG_AVAILABLE ||
                    bnAvailable == TextToSpeech.LANG_COUNTRY_AVAILABLE ||
                    bnAvailable == TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE

            if (!isBanglaSupported) {
                // If specific BD locale isn't installed, check generic "bn"
                val genericBn = Locale("bn")
                val genAvailable = tts?.isLanguageAvailable(genericBn)
                isBanglaSupported = genAvailable == TextToSpeech.LANG_AVAILABLE ||
                        genAvailable == TextToSpeech.LANG_COUNTRY_AVAILABLE
            }
        }
    }

    fun toggleSound(): Boolean {
        isSoundEnabled = !isSoundEnabled
        return isSoundEnabled
    }

    fun isSoundOn(): Boolean = isSoundEnabled

    fun speak(text: String, language: Language, fallbackPhonetic: String = "") {
        if (!isSoundEnabled || !isTtsReady) return

        val targetLocale = if (language == Language.BN) banglaLocale else Locale.US
        val ttsEngine = tts ?: return

        if (language == Language.BN && !isBanglaSupported) {
            // Fallback: speak phonetic or play musical chime
            playBiteSound()
            if (fallbackPhonetic.isNotEmpty()) {
                ttsEngine.language = Locale.US
                ttsEngine.speak(fallbackPhonetic, TextToSpeech.QUEUE_FLUSH, null, "UtteranceId")
            }
            return
        }

        try {
            ttsEngine.language = targetLocale
            ttsEngine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "UtteranceId")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun vibrateShort() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(40)
            }
        } catch (_: Exception) {}
    }

    fun vibrateGentleBump() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.EFFECT_HEAVY_CLICK))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(120)
            }
        } catch (_: Exception) {}
    }

    // Synthesized cheerful sound effects using AudioTrack - 100% offline, zero missing asset errors!
    fun playBiteSound() {
        if (!isSoundEnabled) return
        vibrateShort()
        CoroutineScope(Dispatchers.Default).launch {
            generateToneSweep(startFreq = 523.25, endFreq = 783.99, durationMs = 110)
        }
    }

    fun playWrongSound() {
        if (!isSoundEnabled) return
        vibrateGentleBump()
        CoroutineScope(Dispatchers.Default).launch {
            generateToneSweep(startFreq = 300.0, endFreq = 180.0, durationMs = 220)
        }
    }

    fun playVictorySound() {
        if (!isSoundEnabled) return
        CoroutineScope(Dispatchers.Default).launch {
            // C5 -> E5 -> G5 -> C6 happy fanfare
            val notes = listOf(523.25, 659.25, 783.99, 1046.50)
            for (freq in notes) {
                generateSingleTone(freq, 140)
            }
        }
    }

    fun playClickSound() {
        if (!isSoundEnabled) return
        vibrateShort()
        CoroutineScope(Dispatchers.Default).launch {
            generateToneSweep(startFreq = 880.0, endFreq = 950.0, durationMs = 50)
        }
    }

    private fun generateToneSweep(startFreq: Double, endFreq: Double, durationMs: Int) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val generatedSnd = ShortArray(numSamples)

        var phase = 0.0
        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val currentFreq = startFreq + (endFreq - startFreq) * progress
            val phaseInc = 2 * Math.PI * currentFreq / sampleRate
            phase += phaseInc

            // Apply quick envelope to prevent clicking
            val envelope = when {
                i < numSamples * 0.1 -> i / (numSamples * 0.1)
                i > numSamples * 0.7 -> (numSamples - i) / (numSamples * 0.3)
                else -> 1.0
            }
            generatedSnd[i] = (sin(phase) * 32767 * envelope * 0.45).toInt().toShort()
        }

        playRawAudio(generatedSnd, sampleRate)
    }

    private fun generateSingleTone(freq: Double, durationMs: Int) {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val generatedSnd = ShortArray(numSamples)

        var phase = 0.0
        val phaseInc = 2 * Math.PI * freq / sampleRate
        for (i in 0 until numSamples) {
            phase += phaseInc
            val envelope = when {
                i < numSamples * 0.15 -> i / (numSamples * 0.15)
                i > numSamples * 0.75 -> (numSamples - i) / (numSamples * 0.25)
                else -> 1.0
            }
            generatedSnd[i] = (sin(phase) * 32767 * envelope * 0.5).toInt().toShort()
        }

        playRawAudio(generatedSnd, sampleRate)
    }

    private fun playRawAudio(samples: ShortArray, sampleRate: Int) {
        try {
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(samples, 0, samples.size)
            audioTrack.play()
            Thread.sleep((samples.size * 1000L / sampleRate) + 20)
            audioTrack.release()
        } catch (_: Exception) {}
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
