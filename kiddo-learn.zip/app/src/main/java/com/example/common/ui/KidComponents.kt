package com.example.common.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.game.snakeCore.Direction
import kotlin.math.abs

@Composable
fun KidTopBar(
    title: String,
    subtitle: String? = null,
    onBackClick: () -> Unit,
    isSoundOn: Boolean = true,
    onToggleSound: () -> Unit = {},
    backgroundColor: Color = Color.Transparent,
    textColor: Color = Color(0xFF263238),
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.9f),
            shadowElevation = 3.dp,
            modifier = Modifier.size(50.dp)
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.testTag("kid_top_bar_back")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = textColor,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
        ) {
            Text(
                text = title,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = textColor,
                textAlign = TextAlign.Center
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = textColor.copy(alpha = 0.75f),
                    textAlign = TextAlign.Center
                )
            }
        }

        Surface(
            shape = CircleShape,
            color = Color.White.copy(alpha = 0.9f),
            shadowElevation = 3.dp,
            modifier = Modifier.size(50.dp)
        ) {
            IconButton(
                onClick = onToggleSound,
                modifier = Modifier.testTag("kid_top_bar_sound")
            ) {
                Icon(
                    imageVector = if (isSoundOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = if (isSoundOn) "Mute Sound" else "Unmute Sound",
                    tint = if (isSoundOn) Color(0xFF43A047) else Color(0xFFE53935),
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

@Composable
fun KidGiantButton(
    title: String,
    subtitle: String,
    emoji: String,
    gradientColors: List<Color>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "kid_giant_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 400f),
        label = "button_scale"
    )

    Card(
        shape = RoundedCornerShape(32.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isPressed) 2.dp else 8.dp),
        modifier = modifier
            .scale(scale)
            .height(110.dp)
            .fillMaxWidth()
            .testTag(testTag)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .background(Brush.linearGradient(gradientColors))
                .padding(horizontal = 24.dp, vertical = 16.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = emoji, fontSize = 34.sp)
                }
            }
        }
    }
}

@Composable
fun HeartLivesBar(
    currentLives: Int,
    maxLives: Int = 3,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.85f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for (i in 1..maxLives) {
            val isFull = i <= currentLives
            Icon(
                imageVector = if (isFull) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (isFull) "Full Heart" else "Lost Heart",
                tint = if (isFull) Color(0xFFFF1744) else Color(0xFFB0BEC5),
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun SwipeController(
    onDirectionChange: (Direction) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var totalDragX = 0f
    var totalDragY = 0f

    Box(
        modifier = modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = {
                    totalDragX = 0f
                    totalDragY = 0f
                },
                onDrag = { change, dragAmount ->
                    change.consume()
                    totalDragX += dragAmount.x
                    totalDragY += dragAmount.y
                },
                onDragEnd = {
                    val absX = abs(totalDragX)
                    val absY = abs(totalDragY)
                    val threshold = 30f

                    if (absX > threshold || absY > threshold) {
                        if (absX > absY) {
                            if (totalDragX > 0) {
                                onDirectionChange(Direction.RIGHT)
                            } else {
                                onDirectionChange(Direction.LEFT)
                            }
                        } else {
                            if (totalDragY > 0) {
                                onDirectionChange(Direction.DOWN)
                            } else {
                                onDirectionChange(Direction.UP)
                            }
                        }
                    }
                }
            )
        }
    ) {
        content()
    }
}

@Composable
fun ArrowDPad(
    onDirectionChange: (Direction) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        DPadButton(icon = Icons.Default.KeyboardArrowUp, desc = "Up") {
            onDirectionChange(Direction.UP)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(32.dp)) {
            DPadButton(icon = Icons.Default.KeyboardArrowLeft, desc = "Left") {
                onDirectionChange(Direction.LEFT)
            }
            DPadButton(icon = Icons.Default.KeyboardArrowRight, desc = "Right") {
                onDirectionChange(Direction.RIGHT)
            }
        }
        DPadButton(icon = Icons.Default.KeyboardArrowDown, desc = "Down") {
            onDirectionChange(Direction.DOWN)
        }
    }
}

@Composable
private fun DPadButton(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit
) {
    Surface(
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.9f),
        shadowElevation = 4.dp,
        modifier = Modifier.size(54.dp)
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = icon,
                contentDescription = desc,
                tint = Color(0xFF37474F),
                modifier = Modifier.size(34.dp)
            )
        }
    }
}
