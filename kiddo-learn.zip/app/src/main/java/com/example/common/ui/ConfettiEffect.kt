package com.example.common.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.random.Random

private data class Particle(
    val initialX: Float,
    val initialY: Float,
    val speedY: Float,
    val speedX: Float,
    val size: Float,
    val color: Color,
    val rotationSpeed: Float,
    val isCircle: Boolean
)

@Composable
fun ConfettiCelebration(
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    if (!isActive) return

    val progress = remember { Animatable(0f) }

    val particles = remember {
        val colors = listOf(
            Color(0xFFFF1744), Color(0xFFFF9100), Color(0xFFFFEA00),
            Color(0xFF00E676), Color(0xFF00E5FF), Color(0xFFD500F9),
            Color(0xFFFF4081), Color(0xFF76FF03)
        )
        List(80) {
            Particle(
                initialX = Random.nextFloat(),
                initialY = Random.nextFloat() * -0.4f,
                speedY = Random.nextFloat() * 1.0f + 0.6f,
                speedX = (Random.nextFloat() - 0.5f) * 0.4f,
                size = Random.nextFloat() * 16f + 10f,
                color = colors[Random.nextInt(colors.size)],
                rotationSpeed = (Random.nextFloat() - 0.5f) * 720f,
                isCircle = Random.nextBoolean()
            )
        }
    }

    LaunchedEffect(isActive) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 3500, easing = LinearEasing)
        )
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val t = progress.value

        particles.forEach { p ->
            val curX = (p.initialX + p.speedX * t) * w
            val curY = (p.initialY + p.speedY * t) * h
            val rot = p.rotationSpeed * t

            if (curY in 0f..h && curX in 0f..w) {
                rotate(degrees = rot, pivot = Offset(curX, curY)) {
                    if (p.isCircle) {
                        drawCircle(
                            color = p.color,
                            radius = p.size / 2f,
                            center = Offset(curX, curY)
                        )
                    } else {
                        drawRect(
                            color = p.color,
                            topLeft = Offset(curX - p.size / 2f, curY - p.size / 4f),
                            size = Size(p.size, p.size / 2f)
                        )
                    }
                }
            }
        }
    }
}
