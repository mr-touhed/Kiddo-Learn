# 🌟 Kiddo Learn (হাতেখড়ি ও সাপের খেলা)
**Bangla & English Alphabet + Number Learning App for Kids (with Separated Games)**

A native Android application built with **Kotlin** and **Jetpack Compose (Material 3)** designed for children ages 3–7. The app offers comprehensive learning for:
- **English Alphabet (A–Z)**
- **Bangla Sworoborno / স্বরবর্ণ (অ–ঔ)**
- **Bangla Banjonborno / ব্যঞ্জনবর্ণ (ক–ঁ)**
- **Numbers (English 1–20 & Bangla ১–২০)**

Each learning category features its own **fully separated snake game** with distinct themes, scoring, sounds, and ViewModels.

---

## 🏗 Architecture & Folder Structure

The project enforces strict modularity and separation between learning categories and games:

```
app/
├── src/main/java/com/example/
│   ├── ui/
│   │   ├── home/
│   │   │   └── HomeScreen.kt                 # Home entry (Learn / Game actions)
│   │   ├── navigation/
│   │   │   └── NavGraph.kt                   # Compose Navigation graph
│   │   ├── learn/
│   │   │   ├── learnMenu/
│   │   │   │   └── LearnMenuScreen.kt        # Category selection
│   │   │   ├── english/
│   │   │   │   ├── EnglishLearnScreen.kt     # English A-Z flashcards & grid
│   │   │   │   └── EnglishLearnViewModel.kt
│   │   │   ├── banglaSorborno/
│   │   │   │   ├── BanglaSorbornoLearnScreen.kt
│   │   │   │   └── BanglaSorbornoViewModel.kt
│   │   │   ├── banglaBanjonborno/
│   │   │   │   ├── BanglaBanjonbornoLearnScreen.kt
│   │   │   │   └── BanglaBanjonbornoViewModel.kt
│   │   │   └── numbers/
│   │   │       ├── NumbersLearnScreen.kt     # 1-20 & ১-২০ toggle + counting
│   │   │       └── NumbersLearnViewModel.kt
│   │   └── game/
│   │       ├── gameMenu/
│   │       │   ├── GameMenuScreen.kt         # Game mode cards with high scores
│   │       │   └── GameMenuViewModel.kt
│   │       ├── snakeCore/                    # Reusable snake movement & collision engine
│   │       │   ├── SnakeEngine.kt
│   │       │   └── SnakeBoardView.kt
│   │       ├── snakeEnglish/                 # English Snake (A→B→C...Z)
│   │       │   ├── SnakeEnglishScreen.kt
│   │       │   └── SnakeEnglishViewModel.kt
│   │       ├── snakeSorborno/                # Bangla Vowel Snake (অ→আ→ই...ঔ)
│   │       │   ├── SnakeSorbornoScreen.kt
│   │       │   └── SnakeSorbornoViewModel.kt
│   │       ├── snakeBanjonborno/             # Bangla Consonant Snake (ক→খ...ঁ)
│   │       │   ├── SnakeBanjonbornoScreen.kt
│   │       │   └── SnakeBanjonbornoViewModel.kt
│   │       └── snakeNumbers/                 # Number Snake (1→20 & ১→২০ toggle)
│   │           ├── SnakeNumbersScreen.kt
│   │           └── SnakeNumbersViewModel.kt
│   ├── data/
│   │   ├── database/                         # Room database for High Scores
│   │   │   ├── AppDatabase.kt
│   │   │   ├── HighScoreDao.kt
│   │   │   └── HighScoreEntity.kt
│   │   ├── englishLetters/                   # English letters repository
│   │   ├── banglaSorborno/                   # Bangla vowels repository
│   │   ├── banglaBanjonborno/                # Bangla consonants repository
│   │   ├── numbersEnglish/                   # English numbers repository
│   │   └── numbersBangla/                    # Bangla numbers repository
│   ├── domain/model/
│   │   └── Models.kt                         # LearningItem, Language, HighScoreRecord
│   └── common/
│       ├── audio/
│       │   └── AudioHelper.kt                # TextToSpeech + synthesized sound effects
│       └── ui/
│           ├── KidComponents.kt              # KidTopBar, KidGiantButton, ArrowDPad, HeartLivesBar
│           ├── ConfettiEffect.kt             # Animated victory confetti particles
│           └── ParentalGateDialog.kt         # Math challenge gate for parent verification
└── src/main/assets/data/
    ├── english_letters.json
    ├── bangla_sorborno.json
    ├── bangla_banjonborno.json
    ├── numbers_english.json
    └── numbers_bangla.json
```

---

## 📝 How to Add / Edit Letters, Numbers, or Words

All learning content is stored in clean JSON files under `app/src/main/assets/data/`. You can edit words, emojis, and pronunciations without modifying Kotlin code:

Example entry in `english_letters.json`:
```json
{
  "character": "A",
  "exampleWord": "Apple",
  "pronunciation": "A for Apple",
  "meaning": "Apple",
  "emoji": "🍎",
  "phonetic": "/eɪ/",
  "colorHex": "#FF5252"
}
```

Example entry in `bangla_sorborno.json`:
```json
{
  "character": "অ",
  "exampleWord": "অজগর",
  "pronunciation": "অ তে অজগর",
  "meaning": "Python",
  "emoji": "🐍",
  "phonetic": "Aw",
  "colorHex": "#FF5722"
}
```

To update or add new items:
1. Open the respective JSON file in `app/src/main/assets/data/`.
2. Add or update items in array order.
3. The app repositories load and cache JSON dynamically.

---

## 🌐 How to Add a New Language or New Game Mode

### Adding a New Language (e.g. Spanish or Arabic)
1. Add a new enum value to `Language` in `domain/model/Models.kt`:
   ```kotlin
   enum class Language(val displayName: String, val code: String) {
       EN("English", "en"),
       BN("বাংলা", "bn"),
       ES("Español", "es")
   }
   ```
2. Create a JSON file in `assets/data/` (e.g., `spanish_letters.json`).
3. Create a dedicated repository in `data/spanishLetters/SpanishLettersRepository.kt`.
4. Create dedicated Learn and Game screens adhering to the separated architecture.

### Adding a New Game Mode (e.g. Animal Spelling Snake)
1. In `ui/game/`, create a new package (e.g. `snakeAnimals/`).
2. Implement a `SequenceProvider`:
   ```kotlin
   class AnimalSequenceProvider(val animalNames: List<String>) : SequenceProvider {
       override val sequence = animalNames
   }
   ```
3. Instantiate `SnakeEngine(sequenceProvider = AnimalSequenceProvider(...))` in your new ViewModel.
4. Render the game with `SnakeBoardView` using your custom color theme.

---

## 🔊 Audio & TTS Details

- **TTS Engine**: Uses Android's `TextToSpeech` with `Locale.US` for English and `Locale("bn", "BD")` for Bangla.
- **Offline Sound Synthesis**: Uses real-time PCM audio generation via Android's `AudioTrack`.
  - **Bite Sound**: Pleasant frequency sweep (523Hz → 784Hz)
  - **Wrong Answer**: Soft boing frequency drop (300Hz → 180Hz)
  - **Victory Fanfare**: Ascending C-E-G-C major chord
  - **Click**: Bubbly high-frequency tick
- No external audio files or internet access are required. If you want to use custom `.mp3` recordings, place them in `app/src/main/res/raw/` and play them with `android.media.MediaPlayer`.

---

## 🔒 Safety & COPPA Compliance

- **No Ads, No Trackers**: Zero third-party analytics or external network calls.
- **Parental Verification Gate**: Math challenge modal ("What is 4 + 3?") protects settings and exit navigation.
- **Offline First**: All assets and high scores are stored locally via Room on the device.
